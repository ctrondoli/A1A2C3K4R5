<?php

include('protect.php');
?>

<!DOCTYPE html>
<html lang="pt br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="icon" type="image/png" href="image/LogoFundoT.svg">
    <title>É GOLPE!</title>
</head>
<body>
    
    <object data="layout/menu.html"  type="text/html" class="div1"></object>
    
    
    <div class="home">
        <h2 class="bem-vindo0" style="width: 300px">Bem-vindo ao</h2><h2 class="bem-vindo1" style="width: 400px">É GOLPE!</h2>
        <p class="bem-vindo2">
            Junte-se a causa mantendo-se informado <br>compartilhe ou encontre seu problema aqui.
        </p>
        <img src="image/VFLFundo.svg" class="principal">

        <p>
            <center>
                <p>
                    <a href="../logout.php" class="sair">Sair</a>
                </p>
            </center>
        </p>
    </div>

    <object data="layout/footer.html" type="text/html" class="div1"></object>


</body>
</html>