function menubarra() {
    let barra = document.querySelector('.barra');
    if (barra.classList.contains('open')){
        barra.classList.remove('open');

    }else{
        barra.classList.add('open');
    }
}